# ai-overmind (v3.5.0)

**Build and run a personal AI team. One phrase and your Overmind wakes up.**

The Overmind is a Claude-powered team builder and manager. Install it, say your name, and it learns what you do, proposes a custom team of AI specialists tuned to your actual work, and builds everything for you. You don't write code, you don't manage files, you don't set anything up by hand. Your only jobs are clicking, pasting one block, and saying a passphrase.

The big idea: you talk to one assistant — your Overmind — and it runs the whole team for you. You bring the goal; it writes the detailed instructions each specialist needs (far better and faster than you'd want to) and hands the work off, then brings the result back. You almost never talk to the specialists directly — that's the entire point.

It's built for people who are brand new to this. The Overmind explains every step in plain language, defines every term the first time, and never asks you to do anything technical.

Your team's shared files live in **Google Drive** by default — the Overmind sets up a folder for you and keeps everything there. No Google Drive? It'll offer to help you get one set up. And if you'd rather not, it simply keeps everything in files on your computer.

---

## Quickstart

1. **Rename** the file `ai-overmind.plugin` to `ai-overmind.zip` (just change the ending).
2. **Install it** into a new Cowork project — a project is just a dedicated workspace. Upload the `.zip` when it asks for a plugin.
3. **Open the project.** The Overmind is waiting, quietly.
4. **Type your first name followed by "is online"** — for example, `Sarah is online`.
5. From there, the Overmind takes over: it asks a few friendly questions about your work, proposes your team, lets you pick a style/theme, and then builds the whole thing — walking you through each click, one step at a time.

That's the entire setup. If anything is ever unclear, just tell the Overmind — it will re-explain more simply.

> **One thing to know:** the Overmind will give you a short block of text and ask you to paste it into your project's **Project Instructions** (a settings field). That's the one manual step, and it matters — it's what lets your team wake up reliably each time. The Overmind walks you through exactly where to paste it.

---

## What your Overmind can do

### 1 — Build your team

It interviews you about your work and proposes 5–8 AI specialists, each described in plain terms (what it does *for you*, not jargon). You approve the team, pick a theme that sets the tone, and the Overmind builds every specialist automatically — folders, briefing documents, and personalities. There is no fixed team; yours is designed around what you actually do.

### 2 — Handoffs (memory that survives)

Conversations have limited memory. When you're wrapping up, say **"write a handoff."** The Overmind saves everything — what you did, what's next — and gives you a passphrase. Say that phrase next time and it picks up exactly where you left off, no recap needed. It also offers a handoff on its own when it senses a good stopping point.

### 3 — Dispatch (send work to a teammate)

Tell the Overmind what needs doing and who should do it — for example, *"have my research specialist pull together notes on X."* It writes the assignment, hands you a passphrase, and quietly watches the task in the background. Open that teammate's workspace, say the passphrase, and they start already knowing everything. The Overmind tells you when they're done — you never have to check in. Teammates can hand off to each other the same way.

---

## How the passphrase system works

Everything runs on passphrases. The Overmind writes a brief, invents a passphrase, and tells you what it is. You say the phrase to the right workspace — it wakes up fully briefed. You never write or touch a file. The Overmind handles all of it.

---

## Components

| Component | Purpose |
|-----------|---------|
| `hooks/firmware.md` | The Overmind's core intelligence — beginner guidance, team building, handoffs, dispatch and registry overviews |
| `hooks/hooks.json` | Loads the firmware automatically at the start of every session |
| `skills/overmind/` | Team-building actions; `references/two-tier-bootstrap.md` holds the specialist templates |
| `skills/dispatch/` | The full dispatch procedure — reads your team from `TEAM_ROSTER.md`, never a fixed list |
| `CONNECTORS.md` | Optional directory-service connection for automatic role lookup |

---

## Optional: connect a directory

If you connect a directory service (Teams, Outlook, Google Workspace), the Overmind looks up your role automatically for a smoother first conversation. If you don't, it simply asks you — and works exactly the same. See `CONNECTORS.md`.
