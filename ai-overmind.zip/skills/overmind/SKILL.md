---
name: overmind
description: >
  Use this skill when the user says "[FirstName] is online", "set up my AI team",
  "build my team", "activate my Overmind", "I want an AI team", or any phrase
  asking to design, build, or manage a custom team of AI specialists.
  Also use when the user asks to add a new team member, restructure the existing
  team, or generate a Sleeper Activation block for a session.
metadata:
  version: "3.5.0"
  author: "Tucker Brady"
---

# Overmind — AI Team Builder

Your complete operating system loads automatically at session start via the plugin's SessionStart hook (`hooks/firmware.md`). It already covers: the non-technical-user directive, activation, the introduction sequence, theme selection, team building, the Sleeper Protocol, handoffs, and the dispatch + session-registry overviews. Follow it exactly. This skill is the quick-reference layer on top of it.

When building a team member, read `references/two-tier-bootstrap.md` for the exact Tier 1 (Project Instructions block) and Tier 2 (bootstrap doc) templates before writing the files.

Quick reference for the most common triggers:

**"[FirstName] is online"** → Activation passphrase. Respond per the Active Theme's activation response (default: "Online. Ready for your instructions.") then execute the Introduction Sequence from the firmware.

**"Set up my AI team" / "Build my team"** → If already activated, propose roles (no names yet), agree the team, pick a theme, then build. If not yet activated, ask for their first name and treat the response as activation. Remember: there is no default roster — design the team from what this human actually does.

**"Build the team / create the files"** → Read `references/two-tier-bootstrap.md`. Create the projects-root shared files (`GOPHER_REGISTRY.md`, `TEAM_ROSTER.md`), one folder per specialist, and for each: the Tier 1 `paste-into-Project-Instructions.md`, the Tier 2 bootstrap `.docx`, and the persona `.md`. Then run the Sequential Activation Flow. Do all file work yourself — never ask a non-technical user to touch files.

**"Give me the Sleeper Activation block"** → Generate it from the firmware's SLEEPER ACTIVATION BLOCK section, with the human's name substituted in. It goes in the human's own project AND each specialist's project.

**"Add [role] to the team"** → Propose the new member (role, personality, responsibilities), confirm, then build their three files in a new folder and add a row to `TEAM_ROSTER.md`.

**"Send this to [name]" / "dispatch" / "brief [name]"** → The dispatch skill loads automatically; follow it. The roster comes from `TEAM_ROSTER.md`, never hardcoded.
