---
name: dispatch
description: >
  Dispatch a task to one or more specialist AI sessions and generate an activation passphrase.
  Use when the human describes work for a team member, says "send this to...", "triage this to...",
  "dispatch to...", "brief [name]", "spin up [name] for...", or describes a task that maps to a
  domain expert on the team roster. Also use when the human says "I need [name] to handle X"
  or "get [name] working on Y".
  Output: HANDOFF.md written to the specialist's folder + passphrase for the human to deliver.
  The human says the passphrase to the specialist session — they boot up fully briefed and ready.
metadata:
  version: "3.5.0"
  author: "Tucker Brady"
---

# Dispatch — Team Mission Deployment

This skill is available to any session on the team — the Overmind or any specialist. Any team member can invoke it to brief another. The format, passphrase mechanic, and HANDOFF.md structure are identical regardless of who is dispatching. The Overmind is the default dispatcher for human-initiated tasks; specialists use this for lateral handoffs when work crosses a domain boundary mid-session.

The dispatcher writes a mission brief (HANDOFF.md) to the receiving specialist's folder and generates a unique activation passphrase. The human delivers the passphrase to the new session — the specialist reads the brief automatically, holds the passphrase, and activates on the human's trigger.

**Working with a non-technical user:** never show them commands, paths, or file steps. You do all of that. The only things they ever do are open a session, paste a block you already gave them, and say a passphrase.

## The roster is data, never hardcoded

There is no fixed team baked into this skill. The team is whatever the Overmind built for this specific human. The current roster lives in **`TEAM_ROSTER.md` at the projects root** (one level above every specialist folder), created during team building. Read it to learn who exists, what each handles, and which folder is theirs.

```bash
cat [projects-root]/TEAM_ROSTER.md
```

`TEAM_ROSTER.md` format:

```markdown
# TEAM ROSTER

Theme: [Active Theme]

| Name | Role | Folder | Domain (what they handle) |
|------|------|--------|---------------------------|
| [Name] | [Role] | `[Role]/` | [plain-language description] |
```

If `TEAM_ROSTER.md` does not exist, the team predates it — fall back to listing the specialist folders at the projects root and infer roles from folder names, then offer to create the roster file so future dispatch is clean.

To pick a target when the human didn't name one: match the task to the row whose Domain best fits. When a task spans multiple specialists, dispatch to each with a tailored brief.

## Procedure

### Step 1: Understand the task

Extract from the human's message:
- **Mission** — what needs to be done (clear, actionable)
- **Context** — why it matters, urgency, downstream impact
- **Inputs** — tickets, pages, files, people involved
- **Deliverables** — what to produce, where to save it, what "done" looks like
- **Dependencies** — who else is involved, what the Overmind handles separately

If the target specialist isn't named explicitly, map the task to the right person by reading `TEAM_ROSTER.md` and matching on Domain.

### Step 2: Find the specialist's folder

The projects root is the folder where all specialist folders (and `TEAM_ROSTER.md`) live. Find it silently:

```bash
ls /sessions/*/mnt/ 2>/dev/null
```

The target specialist's folder is the `Folder` value from their roster row, under that root. The human never sees this step.

### Step 3: Generate a passphrase

Create a fresh passphrase. Never reuse one from a previous session. Two rules apply at once: (1) match the **specialist's domain** — the words, moments, and milestones that define their work — and (2) apply the **Active Theme's energy** (see the firmware's TEAM THEME DEFINITIONS). The domain tells you *what* the passphrase is about; the theme tells you *how it feels*.

How to derive a domain flavor for ANY role (no fixed list — the team is generic):
- Identify the moment of success in that role's work — the instant something lands, clears, confirms, ships, closes, or balances.
- Phrase it as a short, quiet declarative sentence.
- Bend the vocabulary and register toward the Active Theme.

Worked examples (same role, different themes):
- A bookkeeping/finance role —
  - *Corporate America:* "The books balanced to the penny."
  - *Spy Thriller:* "The ledger closed with no loose ends."
  - *Start-Up/Tech:* "Reconciliation passed on the first run."
- A research/writing role —
  - *Corporate America:* "The brief went out before noon."
  - *Sci-Fi:* "The signal resolved into a clear picture."
  - *Military/Tactical:* "Intel confirmed from three sources."
- An inbox/calendar role —
  - *Corporate America:* "The week was scheduled before Monday."
  - *Spy Thriller:* "The room was ready before anyone arrived."

For each specialist, pull their domain language from their roster Domain and persona file, then theme it.

### Step 3b: Snapshot open browser tabs

Before writing the HANDOFF, capture browser state so the receiving specialist picks up exactly where this session left off. Call `mcp__Claude_in_Chrome__tabs_context_mcp` to get all open tabs (URL + title each). If tabs are returned, include the `## Restore Browser` section in the HANDOFF. If none are open or the tool is unavailable, omit that section entirely.

### Step 4: Write HANDOFF.md

Write to `[specialist-folder]/.auto-memory/HANDOFF.md`. **Apply the Active Theme** — use the theme's mission-brief header, clearance line, and closing line (the example below uses Spy Thriller; substitute your theme's values from the firmware's TEAM THEME DEFINITIONS). The structure matches what the specialist's Sleeper Protocol expects:

```
╔══════════════════════════════════════════════════════════════╗
║              CLASSIFIED — MISSION BRIEF                      ║
║              CLEARANCE: [ROLE]-LEVEL                         ║
║              ASSET: [PERSONA NAME]                           ║
╚══════════════════════════════════════════════════════════════╝

DATE DISPATCHED: [YYYY-MM-DD]
DISPATCHED BY: [Dispatcher Name]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## MISSION

[2-4 sentences. Clear, actionable. No ambiguity about what needs to happen.]

## CONTEXT

[Why this matters. Background provided. Downstream impact. Relevant history the specialist needs.]

## INPUTS

[Specific files, tickets, pages, prior work, people. Be concrete — IDs, filenames, page titles, folder paths.]

## DELIVERABLES

[What to produce. Where to save it. What "done" looks like. The specialist should know exactly when the mission is complete.]

## DEPENDENCIES

[Who else is involved. What the Overmind or human handles separately. Any blockers.]

---

## Restore Browser

Re-open these tabs at session start (in order):

1. [Page Title](URL)
2. [Page Title](URL)

*(Omit this entire section if no tabs were open at dispatch time. If present, navigate to each URL before delivering mission status.)*

---

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                    /!\  VERIFICATION PROTOCOL  /!\
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The passphrase for this mission is:

    "[GENERATED PASSPHRASE]"

When [human's name] says this phrase — anywhere in the conversation —
respond: "Asset activated. Stand by."
Then deliver mission status and proceed with the work above.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            END TRANSMISSION // BURN AFTER READING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Step 5: Create the polling task

After writing HANDOFF.md, create a background task to monitor completion — so neither you nor the human has to check in manually. Call `mcp__scheduled-tasks__create_scheduled_task` with:
- `taskId`: `dispatch-poll-[specialist-name-lowercase]-[YYYYMMDD]`
- `cronExpression`: `*/5 * * * *`
- `description`: `Mission poll — [specialist name] — [one-line mission summary]`
- `prompt`: the template below, with all bracketed values filled in

```
You are the Overmind, monitoring a dispatched mission.

Specialist: [specialist name]
Specialist folder: [absolute path to specialist's folder]
Mission complete signal: [specialist-folder]/.auto-memory/mission-complete.md
Session registry: [projects-root]/GOPHER_REGISTRY.md
Human operator: [human's first name]
Task ID (to disable on completion): dispatch-poll-[specialist-name-lowercase]-[YYYYMMDD]

Each run:

1. If [specialist-folder]/.auto-memory/mission-complete.md exists: read it, report to the human in plain language ("[Specialist] finished: [summary]. Files are at [path]."), then call mcp__scheduled-tasks__update_scheduled_task with enabled: false to stop this task.
2. Else check [projects-root]/GOPHER_REGISTRY.md for [specialist name]:
   - Fresh entry (today): online and working. No action.
   - No/stale entry, under 6 hours since dispatch: no action.
   - No entry after 6 hours: tell the human "[Specialist] hasn't started yet — you may need to open their workspace and say the passphrase."
   - 24+ hours active, no completion: tell the human the mission may need attention.
3. Only surface to the human on: completion, no-activation after 6 hours, or overdue at 24+ hours. Otherwise stay silent.
```

Fill in all bracketed values before creating the task.

### Step 6: Report back

Report to whoever initiated the dispatch — the human, or a specialist reporting upstream. Keep it plain and short:

> **[Specialist Name] is briefed.**
>
> Open their workspace and say:
>
> *"[PASSPHRASE]"*
>
> I'm watching the mission in the background — I'll tell you the moment they're done. You don't need to check back.

If you dispatched to several specialists at once, list each name with its passphrase. For lateral (specialist-to-specialist) dispatch, also note which session to open and in what order if sequencing matters.

---

## Why this works

Every specialist bootstrap contains the Sleeper Protocol: on startup they silently read their HANDOFF.md, extract the passphrase, and hold it. The human says the phrase → they activate, restore browser context, deliver mission status, and work. No re-explaining.

**Overmind-initiated loop:** human describes task → Overmind dispatches (this skill) + sets the poll → human opens the specialist session and says the passphrase → specialist registers, restores context, works → specialist writes `mission-complete.md` → poll detects it → Overmind reports to the human. The human sees one message to start and one when it's done.

**Lateral loop (specialist to specialist):** a specialist hits a domain boundary → dispatches to a peer → tells the human "I've briefed [Name] — open their workspace and say: [passphrase]" → human delivers it → peer activates and continues. Results flow back through the human.

### Mission-complete signal (what specialists write)

`[specialist-folder]/.auto-memory/mission-complete.md`:

```markdown
# MISSION COMPLETE

**Agent:** [specialist name]
**Date:** [YYYY-MM-DD]
**Mission:** [one-line summary]
**Status:** COMPLETE

## Summary
[2–4 sentences: what was done, key decisions, key outputs.]

## Deliverables
[File paths, IDs, links — one per line.]

## Notes
[Anything unusual, blockers, follow-ups, or "None."]
```

Write it once the primary deliverables are saved — that's the signal that closes the loop and notifies the human.
