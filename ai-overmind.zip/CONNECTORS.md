# Connectors

## How tool references work

Plugin files use `~~category` as a placeholder for whatever tool the user connects in that category. The Overmind plugin is tool-agnostic — it describes workflows in terms of categories rather than specific products.

## Connectors for this plugin

| Category          | Placeholder      | Included options                                      |
| ----------------- | ---------------- | ----------------------------------------------------- |
| Directory service | `~~directory`    | Microsoft Teams, Outlook, Google Workspace, LDAP, Okta |
| Shared drive      | `~~shareddrive`  | Google Drive (default), Box, Dropbox, OneDrive          |

## What the directory connector does

The Overmind uses `~~directory` during activation to look up the user's full name, title, department, manager, and team — so it can introduce itself as a colleague who already did their homework, and propose a team tuned to their actual role.

**If no directory is connected**, the Overmind falls back gracefully: it asks the user directly about their role, team, and what fills their days. The experience is slightly less magical but fully functional.

Connecting a directory connector (Teams, Outlook, Google Workspace) gives the Overmind its best first impression.

## What the shared drive does

The Overmind keeps the team's shared documents (roster, specs, briefs, deliverables, reference docs) in a shared drive. **Google Drive is the default.** If no shared drive is connected, the Overmind offers to help set one up; if the human still declines, it falls back to local files in the project root. Per-session memory and the session registry always stay local regardless. See the firmware's THE SHARED REPOSITORY section for the full decision flow.
